#!/usr/bin/env bash
# This shell script will copy and crop the beginning of your purchased songs
# to be used in their respective Modes.

set -u

# Run from the directory containing this script so relative paths work
# regardless of where the script is invoked from.
cd "$(dirname "$0")" || exit 1

echo "This script will copy and crop the beginning of your purchased songs to be used in their respective Modes."
echo

read -r -p "Are you sure you'd like to continue (Y/[N])? " AREYOUSURE
case "${AREYOUSURE}" in
    [Yy]*) ;;
    *) exit 0 ;;
esac

echo

# Locate ffmpeg: prefer a local copy in this directory, otherwise fall back to PATH.
if [ -x "./ffmpeg" ]; then
    FFMPEG="./ffmpeg"
    echo "Found ./ffmpeg"
elif command -v ffmpeg >/dev/null 2>&1; then
    FFMPEG="$(command -v ffmpeg)"
    echo "Found ffmpeg in PATH ($FFMPEG)"
else
    echo
    echo "Missing requirement: ffmpeg is not available (no ./ffmpeg and not on PATH). Aborting process."
    exit 1
fi

REQUIRED_FILES=(
    "IM_2Minutes.mp3"
    "IM_Aces.mp3"
    "IM_Beast.mp3"
    "IM_Fear.mp3"
    "IM_Flight.mp3"
    "IM_Hallowed.mp3"
    "IM_Hills.mp3"
    "IM_Trooper.mp3"
    "IM_Wasted.mp3"
)

for f in "${REQUIRED_FILES[@]}"; do
    if [ -f "$f" ]; then
        echo "Found $f"
    else
        echo
        echo "Missing requirement: $f does not exist or has not been named correctly. Aborting process."
        exit 1
    fi
done

echo
echo "Found all ${#REQUIRED_FILES[@]} required files"
echo

# Pairs of: start-offset-seconds  input-file
# (output file is derived as <basename>_Mode.mp3)
crop() {
    local start="$1"
    local input="$2"
    local output="${input%.mp3}_Mode.mp3"
    "$FFMPEG" -y -loglevel quiet -stats -ss "$start" -i "$input" -acodec copy "$output"
}

crop 26.5  IM_2Minutes.mp3
crop 40.3  IM_Aces.mp3
crop 77.61 IM_Beast.mp3
crop 103.3 IM_Fear.mp3
crop 5.7   IM_Flight.mp3
crop 6.3   IM_Hallowed.mp3
crop 8.1   IM_Hills.mp3
crop 12.7  IM_Trooper.mp3
crop 13.35 IM_Wasted.mp3

echo
echo 'All done!  You can close this window.  \m/O\m/'
echo
