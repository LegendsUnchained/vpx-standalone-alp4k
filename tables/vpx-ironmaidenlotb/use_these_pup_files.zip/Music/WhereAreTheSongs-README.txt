To get the real music do the following: 

1) Use the links below to buy these MP3s and download.

2) Put the songs in their own folder on your PC

2) Rename to the filenames listed before the link. The naming REALLY matters here!

3) Put ffmpeg.exe in this directory or in your path

	For Windows: 
	https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip
	
	For Mac: 
	https://www.ffmpeg-micro.com/blog/how-to-install-ffmpeg-on-mac-homebrew-and-static-build

4) Run the script to trim the songs and create the mode songs 
   !! WARNING: Be careful when running script files files! Run at your own risk. The Wiz Team can't guarantee these will work !!

   For Windows: 
    1) Download the "Mode_Song_Creator.bat" from /external/vpx-ironmaidenlotb/pupvideos/IM_LOTB/Music/
	2) Put it in the same folder with your MP3s and ffmpeg.exe. 
	3) Run the "Mode_Song_Creator.bat"

   For Mac: 
    1) Download the "mode_song_creator.sh" from /external/vpx-ironmaidenlotb/pupvideos/IM_LOTB/Music/
	2) Put it in the same folder with your MP3s and ffmpeg.exe. 
	3) Run terminal.app in that folder, type ".\mode_song_creator.sh", and hit enter

5) Paste the whole folder in this Music directory for the PUP (/external/vpx-ironmaidenlotb/pupvideos/IM_LOTB/Music) 

6) Ignore overriding any files, you only need the new MP3 files

7) Update the variable at the top of the script to "False" (external/vpx-ironmaidenlotb/vpx-ironmaidenlotb.vbs)
   (wiki help guide: https://wiki.legendsunchained.com/06-manual-table-install-issues/#table-says-to-update-script-how-do-i-do-that)

	Const Music8Bit	= False ' Use 8Bit version of Music 
	
-------------------------------------------------------------------------------------------------------------------------------------------------------
Rename Song To        | Original Song Name             | US Link                                                | UK Link 
IM_2Minutes.mp3         2 Minutes to Midnight           - https://www.amazon.com/music/player/albums/B0F186HJ92  - https://www.amazon.co.uk/music/player/albums/B07VLP1L47
IM_Aces.mp3             Aces High                       - https://www.amazon.com/music/player/albums/B0F186HJ92  - https://www.amazon.co.uk/music/player/albums/B07VLP1L47
IM_Beast.mp3            Number of the Beast             - https://www.amazon.com/music/player/albums/B0F18X6CFC  - https://www.amazon.co.uk/music/player/albums/B07VLNWYTN
IM_Fear.mp3             Fear of the Dark                - https://www.amazon.com/music/player/albums/B0F175B19R  - https://www.amazon.co.uk/music/player/albums/B07VR27J6T
IM_Flight.mp3           Flight of Icarus                - https://www.amazon.com/music/player/albums/B0F183WS55  - https://www.amazon.co.uk/music/player/albums/B07VLP296Z
IM_Ghost.mp3            Ghost of the Navigator          - https://www.amazon.com/music/player/albums/B0DZXTKV6X  - https://www.amazon.co.uk/music/player/albums/B07K7PQH3B
IM_Hallowed.mp3         Hallowed Be Thy Name            - https://www.amazon.com/music/player/albums/B0F18X6CFC  - https://www.amazon.co.uk/music/player/albums/B07VLNWYTN
IM_Hills.mp3            Run To The Hills                - https://www.amazon.com/music/player/albums/B0F18X6CFC  - https://www.amazon.co.uk/music/player/albums/B07VLNWYTN
IM_Madness.mp3          Can I Play With Madness?        - https://www.amazon.com/music/player/albums/B0DZV68ZFR  - https://www.amazon.co.uk/music/player/albums/B07VLP2DRM
IM_Powerslave.mp3       Powerslave                      - https://www.amazon.com/music/player/albums/B0F186HJ92  - https://www.amazon.co.uk/music/player/albums/B07VLP1L47
IM_Rime.mp3             Rime of the Ancient Mariner     - https://www.amazon.com/music/player/albums/B0F186HJ92  - https://www.amazon.co.uk/music/player/albums/B07VLP1L47 - Need the full album for some reason
IM_Speed.mp3            Speed of Light                  - https://www.amazon.com/music/player/albums/B0DZVFZC84  - https://www.amazon.co.uk/music/player/albums/B0101B04CQ
IM_Trooper.mp3          The Trooper                     - https://www.amazon.com/music/player/albums/B0F183WS55  - https://www.amazon.co.uk/music/player/albums/B07VLP296Z
IM_Wasted.mp3           Wasted Years                    - https://www.amazon.com/music/player/albums/B0DZV7K9WD  - https://www.amazon.co.uk/music/player/albums/B07VNTJ3W5
IM_Wicker.mp3           Wicker Man                      - https://www.amazon.com/music/player/albums/B0DZXTKV6X  - https://www.amazon.co.uk/music/player/albums/B07K7PQH3B
MusicEndOfGame.mp3      The Trooper (Again)             - https://www.amazon.com/music/player/albums/B0F183WS55  - https://www.amazon.co.uk/music/player/albums/B07VLP296Z

